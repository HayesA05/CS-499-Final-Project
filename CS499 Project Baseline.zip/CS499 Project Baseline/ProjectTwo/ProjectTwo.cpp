#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>

using namespace std;

struct Course {
    string courseNumber;  //Course identifier
    string courseTitle;   //Course name "Introduction to programming in C++"
    vector<string> prerequisites;  //List of the prerequisite course numbers.
};

// Convert string to uppercase (for Lower to Upper case comparison)
string toUpper(const string& str) {
    string result = str;
    for (char& c : result)
        c = toupper(c);
    return result;
}

// Used to split string by delimiter (comma)
vector<string> split(const string& line, char delimiter = ',') {
    vector<string> tokens;
    string token;
    istringstream tokenStream(line);
    while (getline(tokenStream, token, delimiter)) {
        // Trim whitespace
        token.erase(0, token.find_first_not_of(" \t\r\n"));
        token.erase(token.find_last_not_of(" \t\r\n") + 1);
        tokens.push_back(token);
    }
    return tokens;
}

// Load courses into a hash table
void loadCourses(const string& filename, unordered_map<string, Course>& courseTable) {
    courseTable.clear();
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file: " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        vector<string> tokens = split(line);
        if (tokens.size() < 2) continue;  //Skip invalid lines

        Course course;
        course.courseNumber = toUpper(tokens[0]);
        course.courseTitle = tokens[1];

        //Read remaining tokens
        for (size_t i = 2; i < tokens.size(); ++i) {
            course.prerequisites.push_back(toUpper(tokens[i]));
        }

        //Insert course into hash table using courseNumber as key
        courseTable[course.courseNumber] = course;
    }

    file.close();
    cout << "Data loaded successfully." << endl;
}

// Print sorted list of courses
void printCourseList(const unordered_map<string, Course>& courseTable) {
    vector<string> keys;
    for (const auto& pair : courseTable) {
        keys.push_back(pair.first);
    }
    sort(keys.begin(), keys.end());

    cout << "Here is a sample schedule:" << endl;
    for (const string& key : keys) {
        const Course& course = courseTable.at(key);
        cout << course.courseNumber << ", " << course.courseTitle << endl;
    }
}

// Print info about a specific course
void printCourseDetails(const unordered_map<string, Course>& courseTable, const string& input) {
    string courseNumber = toUpper(input);
    auto it = courseTable.find(courseNumber);
    if (it == courseTable.end()) {
        cout << "Course not found." << endl;
        return;
    }

    const Course& course = it->second;
    cout << course.courseNumber << ", " << course.courseTitle << endl;
    if (course.prerequisites.empty()) {
        cout << "Prerequisites: None" << endl;
    }
    else {
        cout << "Prerequisites: ";
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            cout << course.prerequisites[i];
            if (i < course.prerequisites.size() - 1) cout << ", ";
        }
        cout << endl;
    }
}

// Show menu
void displayMenu() {
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
}

// Main
int main() {
    unordered_map<string, Course> courseTable;
    int choice;
    string input;
    bool dataLoaded = false;

    cout << "Welcome to the course planner." << endl;

    do {
        displayMenu();
        cout << "What would you like to do? ";
        cin >> input;

        try {
            choice = stoi(input);
        }
        catch (...) {
            choice = -1;
        }

        switch (choice) {
        case 1: {
            string filename;
            cout << "Enter the file name: ";
            cin >> filename;
            loadCourses(filename, courseTable);
            dataLoaded = !courseTable.empty();
            break;
        }
        case 2:
            if (!dataLoaded) {
                cout << "Please load the data first using Option 1." << endl;
            }
            else {
                printCourseList(courseTable);
            }
            break;
        case 3:
            if (!dataLoaded) {
                cout << "Please load the data first using Option 1." << endl;
            }
            else {
                cout << "What course do you want to know about? ";
                cin >> input;
                printCourseDetails(courseTable, input);
            }
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            break;
        default:
            cout << input << " is not a valid option." << endl;
        }
    } while (choice != 9);

    return 0;
}
